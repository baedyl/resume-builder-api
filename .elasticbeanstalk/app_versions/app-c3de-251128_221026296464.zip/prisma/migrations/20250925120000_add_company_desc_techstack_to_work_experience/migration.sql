-- AlterTable
ALTER TABLE "WorkExperience"
ADD COLUMN "companyDescription" TEXT,
ADD COLUMN "techStack" TEXT;
