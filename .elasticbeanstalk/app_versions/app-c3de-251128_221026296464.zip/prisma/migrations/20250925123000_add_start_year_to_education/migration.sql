-- AlterTable
ALTER TABLE "Education"
ADD COLUMN "startYear" INTEGER;
